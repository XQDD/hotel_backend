package com.zheng.hotel.repository;


import com.zheng.hotel.bean.record.SystemOperation;

public interface SystemOperationRepository extends BaseRepository<SystemOperation> {
}
