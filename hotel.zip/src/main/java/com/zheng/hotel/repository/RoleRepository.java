package com.zheng.hotel.repository;


import com.zheng.hotel.bean.rbac.Role;

public interface RoleRepository extends BaseRepository<Role> {
}
